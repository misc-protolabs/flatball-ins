x-IMU-MATLAB-Library
====================

Library for importing and structuring x-IMU data in MATLAB using object oriented code.  Includes example data and script.  Does not provide any functionality for real-time communication with x-IMU.
