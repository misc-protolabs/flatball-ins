"""Frispy module."""

# TODO: figure out how to use poetry-bumpversion
# to keep this in line with the pyproject.toml
__version__ = "2.0.0"
