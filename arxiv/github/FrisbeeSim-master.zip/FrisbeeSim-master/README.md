# FrisbeeSim
Simulating the flight of frisbees

Simulate_flight_hummel calls discfltEOM, so make sure you have both downloaded. This code uses simulation techniques developed by Potts, and wind tunnel data found from both Potts and Hummel. 

Crowther, W. J., and J. R. Potts. "Simulation of a spinstabilised sports disc." Sports Engineering 10.1 (2007): 3-21.

Hummel, S.A. (2003) Frisbee Flight Simulation and Throw Biomechanics, PhD Thesis, Univ. California, Davis, USA
