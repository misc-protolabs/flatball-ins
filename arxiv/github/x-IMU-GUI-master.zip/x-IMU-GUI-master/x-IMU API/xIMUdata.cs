﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace x_IMU_API
{
    /// <summary>
    /// x-IMU data class. Base class cannot be instantiated.
    /// </summary>
    public abstract class xIMUdata
    {
    }
}