x-IMU-GUI
=========

Project source files for the x-IMU GUI and API.  The GUI provides access to all features and functionality of the x-IMU and is intended to serve as a comprehensive template for any software interfacing the x-IMU using the API.  See the [x-IMU web page](http://www.x-io.co.uk/products/x-imu/) for more information.

Version history
---------------

* **v13.1**  Add units to graph form captions
* **v13.0**  GUI and API projects combined.  Introduction of auxiliary port mode: *Sleep/Wake*
* **v12.5**  Binary files conversion no longer limited by the RAM of a machine
