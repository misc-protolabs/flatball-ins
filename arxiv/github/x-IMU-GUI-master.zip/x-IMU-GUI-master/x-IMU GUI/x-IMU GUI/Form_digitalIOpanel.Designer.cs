﻿namespace x_IMU_GUI
{
    partial class Form_digitalIOpanel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.checkBox_AX0 = new System.Windows.Forms.CheckBox();
            this.checkBox_AX1 = new System.Windows.Forms.CheckBox();
            this.checkBox_AX3 = new System.Windows.Forms.CheckBox();
            this.checkBox_AX2 = new System.Windows.Forms.CheckBox();
            this.checkBox_AX5 = new System.Windows.Forms.CheckBox();
            this.checkBox_AX4 = new System.Windows.Forms.CheckBox();
            this.checkBox_AX7 = new System.Windows.Forms.CheckBox();
            this.checkBox_AX6 = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // checkBox_AX0
            // 
            this.checkBox_AX0.AutoSize = true;
            this.checkBox_AX0.Location = new System.Drawing.Point(12, 35);
            this.checkBox_AX0.Name = "checkBox_AX0";
            this.checkBox_AX0.Size = new System.Drawing.Size(46, 17);
            this.checkBox_AX0.TabIndex = 0;
            this.checkBox_AX0.Text = "AX0";
            this.checkBox_AX0.UseVisualStyleBackColor = true;
            this.checkBox_AX0.CheckedChanged += new System.EventHandler(this.checkBox_CheckedChanged);
            // 
            // checkBox_AX1
            // 
            this.checkBox_AX1.AutoSize = true;
            this.checkBox_AX1.Location = new System.Drawing.Point(12, 12);
            this.checkBox_AX1.Name = "checkBox_AX1";
            this.checkBox_AX1.Size = new System.Drawing.Size(46, 17);
            this.checkBox_AX1.TabIndex = 1;
            this.checkBox_AX1.Text = "AX1";
            this.checkBox_AX1.UseVisualStyleBackColor = true;
            this.checkBox_AX1.CheckedChanged += new System.EventHandler(this.checkBox_CheckedChanged);
            // 
            // checkBox_AX3
            // 
            this.checkBox_AX3.AutoSize = true;
            this.checkBox_AX3.Location = new System.Drawing.Point(64, 12);
            this.checkBox_AX3.Name = "checkBox_AX3";
            this.checkBox_AX3.Size = new System.Drawing.Size(46, 17);
            this.checkBox_AX3.TabIndex = 3;
            this.checkBox_AX3.Text = "AX3";
            this.checkBox_AX3.UseVisualStyleBackColor = true;
            this.checkBox_AX3.CheckedChanged += new System.EventHandler(this.checkBox_CheckedChanged);
            // 
            // checkBox_AX2
            // 
            this.checkBox_AX2.AutoSize = true;
            this.checkBox_AX2.Location = new System.Drawing.Point(64, 35);
            this.checkBox_AX2.Name = "checkBox_AX2";
            this.checkBox_AX2.Size = new System.Drawing.Size(46, 17);
            this.checkBox_AX2.TabIndex = 2;
            this.checkBox_AX2.Text = "AX2";
            this.checkBox_AX2.UseVisualStyleBackColor = true;
            this.checkBox_AX2.CheckedChanged += new System.EventHandler(this.checkBox_CheckedChanged);
            // 
            // checkBox_AX5
            // 
            this.checkBox_AX5.AutoSize = true;
            this.checkBox_AX5.Location = new System.Drawing.Point(116, 12);
            this.checkBox_AX5.Name = "checkBox_AX5";
            this.checkBox_AX5.Size = new System.Drawing.Size(46, 17);
            this.checkBox_AX5.TabIndex = 5;
            this.checkBox_AX5.Text = "AX5";
            this.checkBox_AX5.UseVisualStyleBackColor = true;
            this.checkBox_AX5.CheckedChanged += new System.EventHandler(this.checkBox_CheckedChanged);
            // 
            // checkBox_AX4
            // 
            this.checkBox_AX4.AutoSize = true;
            this.checkBox_AX4.Location = new System.Drawing.Point(116, 35);
            this.checkBox_AX4.Name = "checkBox_AX4";
            this.checkBox_AX4.Size = new System.Drawing.Size(46, 17);
            this.checkBox_AX4.TabIndex = 4;
            this.checkBox_AX4.Text = "AX4";
            this.checkBox_AX4.UseVisualStyleBackColor = true;
            this.checkBox_AX4.CheckedChanged += new System.EventHandler(this.checkBox_CheckedChanged);
            // 
            // checkBox_AX7
            // 
            this.checkBox_AX7.AutoSize = true;
            this.checkBox_AX7.Location = new System.Drawing.Point(168, 12);
            this.checkBox_AX7.Name = "checkBox_AX7";
            this.checkBox_AX7.Size = new System.Drawing.Size(46, 17);
            this.checkBox_AX7.TabIndex = 7;
            this.checkBox_AX7.Text = "AX7";
            this.checkBox_AX7.UseVisualStyleBackColor = true;
            this.checkBox_AX7.CheckedChanged += new System.EventHandler(this.checkBox_CheckedChanged);
            // 
            // checkBox_AX6
            // 
            this.checkBox_AX6.AutoSize = true;
            this.checkBox_AX6.Location = new System.Drawing.Point(168, 35);
            this.checkBox_AX6.Name = "checkBox_AX6";
            this.checkBox_AX6.Size = new System.Drawing.Size(46, 17);
            this.checkBox_AX6.TabIndex = 6;
            this.checkBox_AX6.Text = "AX6";
            this.checkBox_AX6.UseVisualStyleBackColor = true;
            this.checkBox_AX6.CheckedChanged += new System.EventHandler(this.checkBox_CheckedChanged);
            // 
            // Form_digitalIOpanel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(220, 63);
            this.Controls.Add(this.checkBox_AX7);
            this.Controls.Add(this.checkBox_AX6);
            this.Controls.Add(this.checkBox_AX5);
            this.Controls.Add(this.checkBox_AX4);
            this.Controls.Add(this.checkBox_AX3);
            this.Controls.Add(this.checkBox_AX2);
            this.Controls.Add(this.checkBox_AX1);
            this.Controls.Add(this.checkBox_AX0);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form_digitalIOpanel";
            this.Text = "Digital I/O Panel";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form_digitalIOpanel_FormClosing);
            this.VisibleChanged += new System.EventHandler(this.Form_digitalIOpanel_VisibleChanged);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.CheckBox checkBox_AX0;
        private System.Windows.Forms.CheckBox checkBox_AX1;
        private System.Windows.Forms.CheckBox checkBox_AX3;
        private System.Windows.Forms.CheckBox checkBox_AX2;
        private System.Windows.Forms.CheckBox checkBox_AX5;
        private System.Windows.Forms.CheckBox checkBox_AX4;
        private System.Windows.Forms.CheckBox checkBox_AX7;
        private System.Windows.Forms.CheckBox checkBox_AX6;
    }
}