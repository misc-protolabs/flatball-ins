x-IMU-Arduino-Example
=====================

Generic C++ library for receiving data from the [x-IMU](http://www.x-io.co.uk/x-imu/), implemented and tested with Arduino.  x-IMU auxiliary port must be configured for UART mode, see x_IMU_Arduino_Example.ino for details.

=========

<img src="https://raw.github.com/xioTechnologies/x-IMU-Arduino-Example/master/Test%20Setup.jpg" style="width: 600px;"/>
